@extends('layouts.main')

@section('content')

<!-- Slider Start -->

<div class="home">
    <div class="home_slider_container">

        <!-- Home Slider -->
        <div class="owl-carousel owl-theme home_slider">

            <!-- Slider Item -->
            <div class="owl-item home_slider_item">
                <div class="home_slider_background" style="background-image:url(user/img/bg6.jpg)"></div>
                <div class="home_slider_content_container">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="home_slider_content" data-animation-in="fadeIn" data-animation-out="animate-out fadeOut">
                                    <div class="home_slider_title">A new Online Shop experience.</div>
                                    <div class="home_slider_subtitle">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam a ultricies metus. Sed nec molestie eros. Sed viverra velit venenatis fermentum luctus.</div>
                                    <div class="button button_light home_button"><a href="#">Shop Now</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slider Item -->
            <div class="owl-item home_slider_item">
                <div class="home_slider_background" style="background-image:url(user/img/bg5.jpg)"></div>
                <div class="home_slider_content_container">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="home_slider_content" data-animation-in="fadeIn" data-animation-out="animate-out fadeOut">
                                    <div class="home_slider_title">A new Online Shop experience.</div>
                                    <div class="home_slider_subtitle">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam a ultricies metus. Sed nec molestie eros. Sed viverra velit venenatis fermentum luctus.</div>
                                    <div class="button button_light home_button"><a href="#">Shop Now</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slider Item -->
            <div class="owl-item home_slider_item">
                <div class="home_slider_background" style="background-image:url(user/img/bg1.jpg)"></div>
                <div class="home_slider_content_container">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="home_slider_content" data-animation-in="fadeIn" data-animation-out="animate-out fadeOut">
                                    <div class="home_slider_title">A new Online Shop experience.</div>
                                    <div class="home_slider_subtitle">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam a ultricies metus. Sed nec molestie eros. Sed viverra velit venenatis fermentum luctus.</div>
                                    <div class="button button_light home_button"><a href="#">Shop Now</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Home Slider Dots -->

        <div class="home_slider_dots_container">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="home_slider_dots">
                            <ul id="home_slider_custom_dots" class="home_slider_custom_dots">
                                <li class="home_slider_custom_dot active">01.</li>
                                <li class="home_slider_custom_dot">02.</li>
                                <li class="home_slider_custom_dot">03.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Slider End-->
<div class="menu menu_mm trans_300">
    <div class="menu_container menu_mm">
        <div class="page_menu_content">

            <div class="page_menu_search menu_mm">
                <form action="#">
                    <input type="search" required="required" class="page_menu_search_input menu_mm" placeholder="Search for products...">
                </form>
            </div>
            <ul class="page_menu_nav menu_mm">
                <li class="page_menu_item has-children menu_mm">
                    <a href="index.html">Home<i class="fa fa-angle-down"></i></a>
                    <ul class="page_menu_selection menu_mm">
                        <li class="page_menu_item menu_mm"><a href="categories.html">Categories<i class="fa fa-angle-down"></i></a></li>
                        <li class="page_menu_item menu_mm"><a href="product.html">Product<i class="fa fa-angle-down"></i></a></li>
                        <li class="page_menu_item menu_mm"><a href="cart.html">Cart<i class="fa fa-angle-down"></i></a></li>
                        <li class="page_menu_item menu_mm"><a href="checkout.html">Checkout<i class="fa fa-angle-down"></i></a></li>
                        <li class="page_menu_item menu_mm"><a href="contact.html">Contact<i class="fa fa-angle-down"></i></a></li>
                    </ul>
                </li>
                <li class="page_menu_item has-children menu_mm">
                    <a href="categories.html">Categories<i class="fa fa-angle-down"></i></a>
                    <ul class="page_menu_selection menu_mm">
                        <li class="page_menu_item menu_mm"><a href="categories.html">Category<i class="fa fa-angle-down"></i></a></li>
                        <li class="page_menu_item menu_mm"><a href="categories.html">Category<i class="fa fa-angle-down"></i></a></li>
                        <li class="page_menu_item menu_mm"><a href="categories.html">Category<i class="fa fa-angle-down"></i></a></li>
                        <li class="page_menu_item menu_mm"><a href="categories.html">Category<i class="fa fa-angle-down"></i></a></li>
                    </ul>
                </li>
                <li class="page_menu_item menu_mm"><a href="index.html">Accessories<i class="fa fa-angle-down"></i></a></li>
                <li class="page_menu_item menu_mm"><a href="#">Offers<i class="fa fa-angle-down"></i></a></li>
                <li class="page_menu_item menu_mm"><a href="contact.html">Contact<i class="fa fa-angle-down"></i></a></li>
            </ul>
        </div>
    </div>

    <div class="menu_close"><i class="fa fa-times" aria-hidden="true"></i></div>
</div>

<!-- Order Button Start-->

<div class="myorder">
    <div class="container my-4">
        <div class="border border-light mb-4">
            <div class="text-center">
                <button class="white" type="button" class="btn">Orders Pickup</button>
                <button class="black" type="button" class="btn">Order Delivery</button>
            </div>

        </div>

    </div>
</div>
<section class="akame-service-area section-padding-80-0">
    <div class="container">
        <div class="row">

            <!-- Single Service Area -->
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="single-service-area text-center mb-80 wow fadeInUp" data-wow-delay="200ms">
                    <img src="{{ asset('user') }}/img/buy1.png" alt="">

                    <label class="white" type="button" class="btn"><span>Rs. 750</span></label>
                    <button class="black" type="button" class="btn">Order Delivery</button>

                </div>
            </div>

            <!-- Single Service Area -->
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="single-service-area text-center mb-80 wow fadeInUp" data-wow-delay="200ms">
                    <img src="{{ asset('user') }}/img/buy2.png" alt="">

                    <label class="white" type="button" class="btn"><span>Rs. 750</span></label>
                    <button class="black" type="button" class="btn">Order Delivery</button>

                </div>
            </div>

            <!-- Single Service Area -->
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="single-service-area text-center mb-80 wow fadeInUp" data-wow-delay="200ms">
                    <img src="{{ asset('user') }}/img/buy3.png" alt="">

                    <label class="white" type="button" class="btn"><span>Rs. 750</span></label>
                    <button class="black" type="button" class="btn">Order Delivery</button>

                </div>
            </div>

            <!-- Single Service Area -->
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="single-service-area text-center mb-80 wow fadeInUp" data-wow-delay="200ms">
                    <img src="{{ asset('user') }}/img/buy1.png" alt="">

                    <label class="white" type="button" class="btn"><span>Rs. 750</span></label>
                    <button class="black" type="button" class="btn">Order Delivery</button>

                </div>
            </div>

        </div>
    </div>
</section>

<div class="avds">
    <div class="avds_container d-flex flex-lg-row flex-column align-items-start justify-content-between">
        <div class="avds_small">
            <div class="avds_background" style="background-image:url(user/img/discount_img.jpg)"></div>
            <div class="avds_small_inner">
                <div class="avds_discount_container">

                    <div>
                        <div class="avds_discount">
                            <div>20<span>%</span></div>
                            <div>Discount</div>
                        </div>
                    </div>
                </div>
                <div class="avds_small_content">
                    <div class="avds_title">Smart Phones</div>
                    <div class="avds_link"><a href="categories.html">See More</a></div>
                </div>
            </div>
        </div>
        <div class="avds_large">
            <div class="avds_background" style="background-image:url(user/img/pro_img.jpeg)"></div>
            <div class="avds_large_container">
                <div class="avds_large_content">
                    <div class="avds_title">Professional Cameras</div>
                    <div class="avds_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam a ultricies metus. Sed nec molestie eros. Sed viver ra velit venenatis fermentum luctus.</div>
                    <div class="avds_link avds_link_large"><a href="categories.html">See More</a></div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="upper-svg" class="col-12">

    <svg xmlns="" viewBox="0 0 1440 240">
        <path fill="#f6bf2d" fill-opacity="1" d="M0,64L1440,0L1440,0L0,0Z"></path>
    </svg>
    <div class="mobile row padding">
        <div class="mobile-img col-md-6" data-aos="fade-right">
            <img src="{{ asset('user') }}/img/mockup2.png">
        </div>

        <div class="mobile-content col-md-6" style="margin-top: 15%; margin-left: -10%;">
            <img src="{{ asset('user') }}/img/logo.png" style="width: 15%; text-align: center;">
            <h2 style="padding: 10px; " data-aos="fade-left"><strong style="font-size: 50px;">Download Our App</strong></h2>
            <p class="padding" style="padding-top: 10px;" data-aos="fade-left">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
            <div class="play" style="padding: 10px;">
                <img style=" width: 30%;" src="{{ asset('user') }}/img/service/play_store.png" data-aos="fade-up">
                <img style=" width: 30%;" src="{{ asset('user') }}/img/service/app_store.png" data-aos="fade-up">
            </div>
        </div>
    </div>

</div>

<div class="avds_xl" style="margin-bottom: 15px;">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="avds_xl_container clearfix">
                    <div class="avds_xl_background" style="background-image:url(user/img/banner1.jpg)"></div>
                    <div class="avds_xl_content">
                        <div class="avds_title">Healthy Meal</div>
                        <div class="avds_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam a ultricies metus.</div>
                        <div class="avds_link avds_xl_link"><a href="categories.html">See More</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
<div class="upper-svg" class="col-12" style="margin-bottom:-25%;">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#f6bf2d" fill-opacity="1" d="M0,192L120,165.3C240,139,480,85,720,90.7C960,96,1200,160,1320,192L1440,224L1440,0L1320,0C1200,0,960,0,720,0C480,0,240,0,120,0L0,0Z"></path>
    </svg>
</div>


@endsection