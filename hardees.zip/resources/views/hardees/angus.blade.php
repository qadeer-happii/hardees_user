@extends('layouts.main')

@section('content')
<div style="background-color:#c4c4b3; margin-top: 10%; margin-bottom: 5%;">
    <div style=" background-color:white; height: 450; width: 1350;">
        <div class="container" style="background-color: black;">
            <div class="row">
                <div class="col-sm-8">
                    <br>
                    <h5 class="text-light"><b> Classic Angus Thick Burger</b></h5>
                    <p style="color:#f6bf2d"><b>Selection Variation</b></p>
                    <input type="radio">
                    <label class="text-light"><b>Ala Carte</b></label><br>
                    <input type="radio">
                    <label class="text-light"><b>With Drink</b></label><br>
                    <input type="radio">
                    <label class="text-light"><b>Regular Combo</b></label><br>
                    <input type="radio">
                    <label class="text-light"><b>Medium Combo</b></label><br>
                    <input type="radio">
                    <label class="text-light"><b>Large Combo</b></label><br>
                    <p style="color:#f6bf2d"><b>Add Ones</b></p>
                    <p class="text-light"><b>Select up to 4( Optional )</b></p>
                    <input type="radio">
                    <label class="text-light"><b>Mushroom</b></label><br>
                    <input type="radio">
                    <label class="text-light"><b>Jalapeno</b></label><br>
                    <input type="radio">
                    <label class="text-light"><b>Cheese</b></label><br>
                    <input type="radio">
                    <label class="text-light"><b>Dip Sauce</b></label><br>
                    <p style="color:#f6bf2d"><b>Extra Angus Patty</b></p>
                    <p style="color:#f6bf2d"><b>Optional</b></p>
                    <input type="radio">
                    <label class="text-light"><b>Angus Patty</b></label><br>

                </div>

                <div class="col-sm-4 text-right">
                    <br>
                    <h5 class="text-light"><b>PKR890.00</b></h5>
                    <p style="color:black"><b>Selection Variation</b></p>
                    <label class="text-light"><b>PKR890.00</b></label><br>
                    <label class="text-light"><b>PKR990.00</b></label><br>
                    <label class="text-light"><b>PKR1,210.00</b></label><br>
                    <label class="text-light"><b>PKR1,260.00</b></label><br>
                    <label class="text-light"><b>PKR1,260.00</b></label><br>
                    <p class="text-light"><b>Optional</b></p>
                    <p style="color:black;"><b>Select up to 4( Optional )</b></p>
                    <label class="text-light"><b>PKR 100.00</b></label><br>
                    <label class="text-light"><b>PKR 50.00</b></label><br>
                    <label class="text-light"><b>PKR 40.00</b></label><br>
                    <label class="text-light"><b>PKR1,260.00</b></label><br>
                    <p style="color:black"><b>Extra Angus Patty</b></p>
                    <p style="color:#f6bf2d"><b>Optional</b></p>
                    <label class="text-light"><b>PKR 370.00</b></label><br>

                </div>
            </div>

            <p class="text-light"><b>Special Instructions<br> You can write down here specil Instructions</b></p>
            <div class="container">
                <textarea rows="4" class="form-control" cols="50">
        At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies.
        </textarea>
                <br>
                <br>

                <div class="input-group text-right" style="margin-left: 600px;;">
                    <span class="input-group-btn">
                        <button type="button" class="btn  text-warning  " style="background-color:black; border:1px solid #f6bf2d;;" data-type="minus" data-field=""><b>-</b></button>

                        </button>
                    </span>
                    <input type="text" id="quantity" name="quantity" class="  input-number" value="10" min="1" max="100">
                    <span class="input-group-btn">
                        <button type="button" class="quantity-right-plus btn  btn-number text-warning" style="background-color:black;  border:1px solid #f6bf2d;;" data-type="plus" data-field=""><b>+</b></button><button class="btn btn-light text-warning" style="  color:#f6bf2d; margin-left: 2px;"><b>ADD TO BUCKET</b></button>
                    </span>
                </div>

            </div>

            <br><br><br>
        </div>

    </div>
</div>

@endsection