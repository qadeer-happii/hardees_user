<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top:150px ;">
    <div class="row" style="border:1px solid black; margin-top: 15px; margin-bottom: 20px;">
        <div class="col-sm">
            <div style="border:1px solid black; background-color:  white; margin-top: 10px;" class="form-control text-center">
                <h1 style="margin-top: 5px;" class="font-weight-bold">About Us</h1>
            </div>
            <h4 style="margin-top: 50px;" class=" ">Great Food Comes First</h4>
            <p class=" ">Every day, more than 11 million fuests visit Hardees restaurants around the world.And the do so
                because our restaurants are known for serving high-quality, great-tasting and affordable food.
                Founded in 1954s Hardees the second largest food hamburger chain in the world. The original HOME
                OF THE WHOPPER,our commitment to premuim ingredients, signature recipes, and family-frindly dinging
                experiences is what has defined our brand for more than 50 successsful years.

            </p>
            <h4 class="text-dark">Contact</h4>
            <label>Hardees Corporation<br>Call(042)111 2000 400</label><br>
        </div>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hardes\resources\views/hardees/about.blade.php ENDPATH**/ ?>